/*
  PROJECTE:     Geometria — preguntes del llibre (p. 1-55)
  FITXER:       js/i18n/ui-strings.js
  ROL:          Textos d'interfície (allò que l'alumne LLEGEIX a la pantalla:
                botons, etiquetes, missatges d'estat). NO conté contingut de
                preguntes — això viu a js/data/preguntes-dades.js i es
                resol amb el seu propi mecanisme de fallback (en/ca per
                pregunta), independent d'aquest fitxer.
  ARQUITECTURA: Es carrega abans de i18n-core.js, que és qui llegeix
                aquesta estructura. Afegir un idioma nou = una entrada nova
                aquí, sense tocar cap altre fitxer. El selector d'idioma (si
                n'hi ha) s'ha de generar sempre amb
                Object.entries(window.UI_LANGS) — mai amb una llista
                d'opcions escrita a mà — perquè no quedi mai desincronitzat
                amb el contingut real d'aquest fitxer.
  DEPENDÈNCIES: Cap.

  ORIGEN DEL PATRÓ
  Calcat de la forma de K.UI_LANGS a karelcat/js/i18n.js (seccions niuades,
  camp _name per al selector, claus curtes i planes). La PRIORITAT de
  resolució de l'idioma (URL > localStorage > navegador > per defecte) no
  viu aquí — viu a i18n-core.js — però surt de la recepta documentada a
  karelcat/docs/i18n-spanish-guide.md (§"Step 3"), no de codi que ja
  s'executi avui a karelcat (que és monolingüe en producció; aquella guia
  és la recepta per quan s'hi vulgui afegir un segon idioma).

  Aquí, a diferència de karelcat, els DOS idiomes (en/ca) es defineixen
  complets des del primer dia — no n'hi ha cap de "principal" i cap
  de "parcial en construcció".
*/

window.UI_LANGS = {
  en: {
    _name: "English",

    nav: {
      title: "Geometry — questions from the book",
      back: "← Back to all questions",
      filter_all: "All",
      source_note: "Questions drawn from a book on synthetic geometry.",
    },

    list: {
      question_count: "{n} questions",
      question_count_one: "{n} question",
      no_results: "No questions match this filter.",
      no_image_badge: "no figure",
      open: "Open",
      export_button: "Copy my code",
      export_note: "Copies a one-line code with the questions you've explored, so your teacher can turn them into a written test.",
      export_empty: "You haven't explored any question yet",
      export_copied: "Copied — paste it and send it",
      export_manual: "Couldn't copy: select it and press Ctrl+C",
      export_field_label: "Your code",
      export_file: "or download it as a file",
      search_placeholder: "Search by word or number…",
      search_label: "Search the questions",
      search_note: "Searching all questions: the filters below don't apply while there's text in the search box.",
      search_no_results: "No question matches this search.",
    },

    detail: {
      hint_show: "💡 Show hint",
      hint_hide: "💡 Hide hint",
      no_hint: "No hint for this one — sit with it a while.",
      back_to_list: "← All questions",
      prev: "← Previous",
      next: "Next →",
      done_label: "explored",
      projector_on: "Projector mode",
      projector_off: "Leave projector mode",
      projector_help: "→ or space: next hint (then next question) · ←: previous question · Esc: leave",
      print: "Print the worksheet",
      print_note: "Prints the question, its figure and the whole guide (all four hints, the check and what comes next).",
    },

    guide: {
      title: "Proof guide",
      move_label: "The move: {move}",
      start: "Start the guide",
      next_hint: "Show hint {n} of {total}",
      // Les claus (level_0..level_3) segueixen l'índex INTERN de
      // pista.nivell (0-3, mai canvia — v. guies-dades.js/parse_guies.py).
      // El TEXT mostrat és 1-indexat a petició explícita del propietari
      // (cap alumne hauria de veure mai "Pista 0") — desalineat a
      // propòsit, no un error de comptatge.
      level_0: "Hint 1",
      level_1: "Hint 2",
      level_2: "Hint 3",
      level_3: "Hint 4",
      check: "Check your answer",
      after: "And afterwards",
      figure_alt: "Construction: the book's figure in black, what you add in sanguine",
      level_0_fallback: "what you must produce",
      level_1_fallback: "make it concrete",
      level_2_fallback: "the construction",
      level_3_fallback: "close it",
      legend_toggle: "How to read these figures",
    },

    lang: {
      switch_label: "Language",
    },

    meta: {
      untranslated_notice: "This question hasn't been translated yet — showing the original English.",
      question_label: "Question {n}",
    },

    glossary: {
      open_button: "📖 Glossary",
      close_button: "Close",
      title: "Glossary",
      search_placeholder: "Search a term…",
      no_results: "No terms found.",
      back_to_list: "← All terms",
      related_label: "See also:",
      figure_alt: "Diagram illustrating this term",
      uncategorized: "Other",
    },

    itinerary: {
      rate_prompt: "How did this one feel?",
      rate_molt: "Loved it",
      rate_normal: "Fine",
      rate_poc: "Not much",
      suggested_title: "Suggested for you",
      reason_continue: "you started this one",
      reason_adjacent_level: "similar level to what you just did",
      reason_review_moviment: "trains the same idea — {move}",
      reason_fallback: "next in the list",
      continue_banner: "Continue where you left off:",
    },

    // Nom llegible de cada `moviment` de les guies (el slug de
    // guies-dades.js, amb els guions canviats per _). El fa servir
    // geoContingut.nomMoviment() per al suggeriment "entrena la
    // mateixa idea — …" de l'itinerari: abans hi sortia el slug cru
    // ("redueix-al-conegut"). verifica_projecte.py comprova que tot
    // moviment de les guies tingui nom als dos idiomes.
    moves: {
      centre_per_simetria: "find the centre through symmetry",
      redueix_al_conegut: "reduce the unknown to the known",
      recompte_o_induccio: "count every case, or use induction",
      invariant: "look for what doesn't change",
      construeix_per_definir: "build it in order to define it",
      contraexemple: "to refute, one counterexample is enough",
      separa_i_reorienta: "split into pieces and reorient them",
      simetria_i_demostra: "guess by symmetry, then prove",
      distingeix_casos: "split into cases",
      un_altre_pla: "repeat the argument in another plane",
      dues_maneres: "look at the same thing in two ways",
      identitat_com_a_figura: "the identity is the figure",
      estirament: "stretch the figure in one direction",
      homotecia: "scale from a point (homothety)",
      cas_limit: "push it to the limiting case",
      exhauriment: "approximate by exhaustion",
      audita_la_demostracio: "put your own proof to the test",
      linia_no_enunciada: "add a line the statement doesn't mention",
      definicio_i_absurd: "unpack the definition and reach a contradiction",
      informacio_no_usada: "use the information you haven't touched yet",
      desenrotlla: "unroll the surface",
      reflexio: "reflect, and the broken path becomes straight",
    },

    demo: {
      header_link: "What's a proof?",
      eyebrow: "Before the 130 questions",
      page_title: "What's a proof?",
      intro: "Three short, worked examples — solved in full, start to finish — so the real questions ahead read as the same kind of thing, not a different genre. Nothing here is scored or hidden.",
      beat_why: "Why this needs an argument",
      beat_argument: "The argument",
      beat_move: "What just happened",
      move_label: "The move: {move}",
      figure_alt: "The construction, drawn step by step",
      open_question: "Open {id} →",
      back_to_list: "← All 130 questions",
      start: "Start",
      next_step: "Step {n} of {total} →",
      step_label: "Step {n} of {total}",
      try_label: "Try it on paper first",
      check_label: "Check yourself",
    },

    // Itineraris TEMÀTICS (window.ITINERARIS_TEMATICS, HANDOFF-ITINERARIS.md)
    // -- els 6 camins fixos i editorials. Secció separada de "itinerary"
    // (a dalt), que és el motor REACTIU individual per alumne: noms
    // diferents a propòsit perquè no es confonguin ni al codi ni aquí.
    itineraris: {
      header_link: "Themed paths",
      list_card_title: "Follow a themed path",
      list_card_body: "Six fixed sequences through the questions, grouped by topic instead of by page order.",
      list_card_link: "See the 6 paths →",
      eyebrow: "Six fixed sequences",
      page_title: "Themed paths",
      intro: "Each path reorganizes the book's questions by topic instead of page order. The same path for everyone — pick one and work through it top to bottom.",
      count: "{n} questions",
      open: "Start this path →",
      back_to_itineraris: "← All paths",
      back_to_list: "← All questions",
      progress: "Question {n} of {total}",
      requires_label: "Before this one, it helps to have done:",
      next_in_path: "Next in this path",
      path_done: "That's the last question in this path.",
      bessones_title: "Also worth seeing",
    },
  },

  ca: {
    _name: "Català",

    nav: {
      title: "Geometria sintètica",
      back: "← Torna a totes les preguntes",
      filter_all: "Totes",
      source_note: "Preguntes extretes d'un llibre de geometria sintètica.",
    },

    list: {
      question_count: "{n} preguntes",
      question_count_one: "{n} pregunta",
      no_results: "Cap pregunta coincideix amb aquest filtre.",
      no_image_badge: "sense figura",
      open: "Obre",
      export_button: "Copia el meu codi",
      export_note: "Copia un codi d'una línia amb les preguntes que has explorat, perquè el professorat en pugui fer una prova escrita.",
      export_empty: "Encara no has explorat cap pregunta",
      export_copied: "Copiat — enganxa'l i envia'l",
      export_manual: "No s'ha pogut copiar: selecciona'l i prem Ctrl+C",
      export_field_label: "El teu codi",
      export_file: "o descarrega'l com a fitxer",
      search_placeholder: "Cerca per paraula o número…",
      search_label: "Cerca a les preguntes",
      search_note: "Cercant a totes les preguntes: els filtres de sota no s'apliquen mentre hi ha text a la cerca.",
      search_no_results: "Cap pregunta coincideix amb aquesta cerca.",
    },

    detail: {
      hint_show: "💡 Mostra la pista",
      hint_hide: "💡 Amaga la pista",
      no_hint: "Aquesta no té pista — pensa-t'ho amb calma.",
      back_to_list: "← Totes les preguntes",
      prev: "← Anterior",
      next: "Següent →",
      done_label: "explorat",
      projector_on: "Mode projector",
      projector_off: "Surt del mode projector",
      projector_help: "→ o espai: pista següent (i, al final, pregunta següent) · ←: pregunta anterior · Esc: surt",
      print: "Imprimeix la fitxa",
      print_note: "Imprimeix la pregunta, la seva figura i la guia sencera (les quatre pistes, la comprovació i l'i després).",
    },

    guide: {
      title: "Guia de demostració",
      move_label: "El moviment: {move}",
      start: "Comença la guia",
      next_hint: "Mostra la pista {n} de {total}",
      level_0: "Pista 1",
      level_1: "Pista 2",
      level_2: "Pista 3",
      level_3: "Pista 4",
      check: "Comprovació",
      after: "I després",
      figure_alt: "Construcció: la figura del llibre en negre, el que hi afegeixes tu en sanguina",
      level_0_fallback: "què has de produir",
      level_1_fallback: "fes-ho concret",
      level_2_fallback: "la construcció",
      level_3_fallback: "tanca-ho",
      legend_toggle: "Com es llegeixen aquestes figures",
    },

    lang: {
      switch_label: "Idioma",
    },

    meta: {
      untranslated_notice: "Aquesta pregunta encara no s'ha traduït — es mostra l'original en anglès.",
      question_label: "Qüestió {n}",
    },

    glossary: {
      open_button: "📖 Glossari",
      close_button: "Tanca",
      title: "Glossari",
      search_placeholder: "Cerca un terme…",
      no_results: "Cap terme trobat.",
      back_to_list: "← Tots els termes",
      related_label: "Vegeu també:",
      figure_alt: "Diagrama que il·lustra aquest terme",
      uncategorized: "Altres",
    },

    itinerary: {
      rate_prompt: "Què t'ha semblat?",
      rate_molt: "M'ha agradat molt",
      rate_normal: "Normal",
      rate_poc: "No gaire",
      suggested_title: "Suggerit per a tu",
      reason_continue: "l'havies començada",
      reason_adjacent_level: "nivell semblant al que acabes de fer",
      reason_review_moviment: "entrena la mateixa idea — {move}",
      reason_fallback: "la següent de la llista",
      continue_banner: "Continua on ho vas deixar:",
    },

    moves: {
      centre_per_simetria: "troba el centre per simetria",
      redueix_al_conegut: "redueix el desconegut al conegut",
      recompte_o_induccio: "compta tots els casos, o fes-ho per inducció",
      invariant: "busca el que no canvia",
      construeix_per_definir: "construeix per definir",
      contraexemple: "per refutar, en basta un contraexemple",
      separa_i_reorienta: "separa les peces i reorienta-les",
      simetria_i_demostra: "endevina per simetria, després demostra",
      distingeix_casos: "distingeix els casos",
      un_altre_pla: "repeteix l'argument en un altre pla",
      dues_maneres: "mira la mateixa cosa de dues maneres",
      identitat_com_a_figura: "la identitat és la figura",
      estirament: "estira la figura en una sola direcció",
      homotecia: "amplia o redueix des d'un punt (homotècia)",
      cas_limit: "porta-ho al cas límit",
      exhauriment: "aproxima per exhauriment",
      audita_la_demostracio: "posa a prova la teva pròpia demostració",
      linia_no_enunciada: "afegeix una línia que l'enunciat no menciona",
      definicio_i_absurd: "desempaqueta la definició i arriba a l'absurd",
      informacio_no_usada: "fes servir la informació que encara no has tocat",
      desenrotlla: "desenrotlla la superfície",
      reflexio: "reflecteix, i el camí trencat es torna recte",
    },

    demo: {
      header_link: "Què és una demostració?",
      eyebrow: "Abans de les 130 preguntes",
      page_title: "Què és una demostració?",
      intro: "Tres exemples curts, resolts sencers de cap a cap — perquè les preguntes reals que venen després es llegeixin com el mateix tipus de cosa, no com un gènere diferent. Res, aquí, es puntua ni s'amaga.",
      beat_why: "Per què cal un argument",
      beat_argument: "L'argument",
      beat_move: "Què acaba de passar",
      move_label: "El moviment: {move}",
      figure_alt: "La construcció, pas a pas",
      open_question: "Obre {id} →",
      back_to_list: "← Totes les 130 preguntes",
      start: "Comença",
      next_step: "Pas {n} de {total} →",
      step_label: "Pas {n} de {total}",
      try_label: "Prova-ho al paper abans de continuar",
      check_label: "Comprova-ho",
    },

    itineraris: {
      header_link: "Itineraris temàtics",
      list_card_title: "Segueix un itinerari temàtic",
      list_card_body: "Sis seqüències fixes per les preguntes, agrupades per tema en lloc de per ordre de pàgina.",
      list_card_link: "Veure els 6 itineraris →",
      eyebrow: "Sis seqüències fixes",
      page_title: "Itineraris temàtics",
      intro: "Cada itinerari reorganitza les preguntes del llibre per tema en lloc de per ordre de pàgina. El mateix itinerari per a tothom — tria'n un i segueix-lo de dalt a baix.",
      count: "{n} preguntes",
      open: "Comença aquest itinerari →",
      back_to_itineraris: "← Tots els itineraris",
      back_to_list: "← Totes les preguntes",
      progress: "Pregunta {n} de {total}",
      requires_label: "Abans d'aquesta, convé haver fet:",
      next_in_path: "Següent en aquest itinerari",
      path_done: "Aquesta és l'última pregunta de l'itinerari.",
      bessones_title: "Val la pena veure també",
    },
  },
};
